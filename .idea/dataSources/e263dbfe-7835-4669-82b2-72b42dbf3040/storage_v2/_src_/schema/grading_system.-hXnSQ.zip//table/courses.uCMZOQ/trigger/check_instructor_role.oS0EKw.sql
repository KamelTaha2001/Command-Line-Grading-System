create definer = root@localhost trigger check_instructor_role
    before insert
    on courses
    for each row
BEGIN
    DECLARE role_value VARCHAR(50);
    SELECT role INTO role_value FROM users WHERE id = NEW.instructorId;
    IF role_value <> 'INSTRUCTOR' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Cannot insert into courses: instructorId does not correspond to an instructor';
    END IF;
END;

