create definer = root@localhost trigger check_student_role
    before insert
    on grades
    for each row
BEGIN
    DECLARE role_value VARCHAR(50);
    SELECT role INTO role_value FROM users WHERE id = NEW.studentId;
    IF role_value <> 'STUDENT' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Cannot insert into grades: studentId does not correspond to a student';
    END IF;
END;

